<!DOCTYPE html>
<html lang="en">

<?php include_once "partials/head.php"; ?>

<body>
    <div class="container-scroller">
        <?php include_once "partials/nav.php"; ?>

        <!-- partial -->
        <div class="main-panel">
            <div class="content-wrapper">
                <?php  include_once "partials/revenue.php"; ?>

                <?php  include_once "partials/team.php"; ?>

                <?php include_once "partials/visitcountry.php"; ?>
            </div>


            <?php include_once "partials/footer.php";  ?>