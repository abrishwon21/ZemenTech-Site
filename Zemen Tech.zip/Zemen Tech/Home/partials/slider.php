<section id="home" class="home">
    <div class="slider-overlay"></div>
    <div class="flexslider">
        <ul class="slides scroll">
            <li class="first">
                <div class="slider-text-wrapper">
                    <div class="container">
                        <div class="big">Free Responsive Template </div>
                        <div class="small">Are you ready to buy this theme</div>
                        <a href="#works" class="middle btn btn-white">VIEW PORTFOLIO</a>
                    </div>
                </div>
                <img src="images/slider/1.jpg" alt="">
            </li>

            <li class="secondary">
                <div class="slider-text-wrapper">
                    <div class="container">
                        <div class="big">Free Responsive Template </div>
                        <div class="small">Are you ready to buy this theme</div>
                        <a href="#works" class=" middle btn btn-white">VIEW PORTFOLIO</a>
                    </div>
                </div>
                <img src="images/slider/2.jpg" alt="">
            </li>

            <li class="third">
                <div class="slider-text-wrapper">
                    <div class="container">
                        <div class="big">Free Responsive Template </div>
                        <div class="small">Are you ready to buy this theme</div>
                        <a href="#works" class="middle btn btn-white">VIEW PORTFOLIO</a>
                    </div>
                </div>
                <img src="images/slider/3.jpg" alt="">
            </li>
        </ul>
    </div>
</section>