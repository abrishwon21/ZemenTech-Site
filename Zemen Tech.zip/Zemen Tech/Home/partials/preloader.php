<div id="pageloader">
    <div class="loader">
        <img src="images/progress.gif" alt='loader' />
    </div>
</div>